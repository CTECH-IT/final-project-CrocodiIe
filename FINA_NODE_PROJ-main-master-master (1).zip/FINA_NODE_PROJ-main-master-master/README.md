# Example-Partner-Project

Partner #1: Enter your name: Mr. Bartucz
Partner #1: Enter your favorite food: Mr. Pizza

Partner #2: Enter your name: Test Bartucz
Partner #2: Enter your favorite food: Test Pizza

Even though I know my partner is editing this file
I am going to edit the same part as well, moooahahahah!
